/*
클래스 선언시 class키워드를 사용한다. 클래스명의 첫글자는 반드시
대문자로 해야한다. 또한 public이라는 접근지정자는 하나의 java파일에
한번만 사용할 수 있다. 
 */
public class Apple
{
    public void showName()
    {
        System.out.println("My name is apple.");
    }
}