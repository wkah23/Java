public class Book
{
	int num;
}
